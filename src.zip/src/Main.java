import java.io.FileNotFoundException;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        String dna = ReadFromFileUsingScanner.Read();


        // ReturnFrequency(sort(splitString(dna)), "ATT");
        /* Run below method for table */
        /*Need to get arraylist of all possible sequences*/
        getTable(dna, sort(splitString(dna)), PossCombinations("ATGCATGCATGCATGC", 4));



    }
    public static ArrayList<String> PossCombinations(String Chars, int k) {
        int n = Chars.length();
        ArrayList<String> combos = new ArrayList<>();
        ArrayList<String> RemoveCombos = new ArrayList<>();
        if (k == 0) {
            combos.add("");
            return combos;
        }
        if (n < k || n == 0)
            return combos;
        String last = Chars.substring(n-1);
        combos.addAll(PossCombinations(Chars.substring(0, n-1), k));
        for (String subCombo : PossCombinations(Chars.substring(0, n-1), k-1))
            combos.add(subCombo + last);

        for (int i = 0; i < combos.size(); i++) {
            for (int j = i + 1; j < combos.size(); j++) {
                if(combos.get(i).equals(combos.get(j))) RemoveCombos.add(combos.get(i));
            }
        }

        for (int i = 0; i < combos.size(); i++) {
            for (int j = 0; j < RemoveCombos.size(); j++) {
                if(combos.get(i).equals(RemoveCombos.get(j))){
                    combos.remove(i);
                    RemoveCombos.set(j, " ");
                }
            }
        }
        return combos;
    }




    private static void getTable(String dna, DTO dto, ArrayList<String> listSequences){
        for (int i = 0; i < listSequences.size(); i++) {
            ReturnFrequency(sort(splitString(dna)), listSequences.get(i));
        }



    }

    private static void ReturnFrequency(DTO dto, String target) {
        System.out.println("Target sequence: " + target);
        /*MutantList Calculations */
        ArrayList<String> mutantList = dto.getMutantList();
        double mutantListNucCounter = 0;
        double mutantListPatCounter = 0;
        for (int i = 0; i < (mutantList.size()-1); i++) {
            for (int j = 0; j < mutantList.get(i).length() - (target.length()); j++) {
                if (("ATGC").contains(mutantList.get(i).substring(j, (j + 1)))){
                    mutantListNucCounter++;
                }
                if(target.equalsIgnoreCase(mutantList.get(i).substring(j, j+(target.length())))){
                    mutantListPatCounter++;
                }
            }
        }
        System.out.println("Mutant DNA: " + (mutantListPatCounter/mutantListNucCounter)*100 + " occurrences out of 100 nucleotide bases");
//////////////////////////


        /*MutantList Calculations */
        ArrayList<String> normalList = dto.getNormalList();
        double normalListNucCounter = 0;
        double normalListPatCounter = 0;
        for (int i = 0; i < (normalList.size()-1); i++) {
            for (int j = 0; j < normalList.get(i).length() - (target.length()); j++) {
                if (("ATGC").contains(normalList.get(i).substring(j, (j + 1)))){
                    normalListNucCounter++;
                }
                if(target.equalsIgnoreCase(normalList.get(i).substring(j, j+(target.length())))){
                    normalListPatCounter++;
                }
            }
        }
        System.out.println("Normal DNA: " + (normalListPatCounter/normalListNucCounter)*100 + " occurances out of 100 nucleotide bases");


    }

    private static String[] splitString(String input) {
        return input.split(" ");
    }

    private static DTO sort(String[] x) {
        ArrayList<String> MutantList = new ArrayList<String>();
        ArrayList<String> NormalList = new ArrayList<String>();
        for (int i = 0; i < x.length - 1; i++) {
            if (x[i].startsWith("m")) {
                MutantList.add(x[i].substring(0, x[i].length() - 1));
            }
            if (x[i].startsWith("n")) {
                NormalList.add(x[i].substring(0, x[i].length() - 1));
            }
        }

        DTO dto = new DTO(NormalList, MutantList);

        return dto;
    }

}

