public class random {
    public static void main(String[] args) {

    }

}
